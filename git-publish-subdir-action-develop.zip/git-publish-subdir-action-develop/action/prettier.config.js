module.exports = {
  "singleQuote": true
}